//
//  Ios_AppApp.swift
//  Ios_App
//
//  Created by Praveen on 27/06/24.
//

import SwiftUI

@main
struct Ios_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
